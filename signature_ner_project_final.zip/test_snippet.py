"""Quick Test Snippet — Verify trained Signature NER model"""
from transformers import AutoTokenizer, AutoModelForTokenClassification
import torch, json
from collections import defaultdict

MODEL_DIR = "./outputs/signature-ner-distilbert"

tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
model = AutoModelForTokenClassification.from_pretrained(MODEL_DIR)
id2label = model.config.id2label

def _detok(tokens):
    s = " ".join(tokens).replace(" ##", "").replace("# #", "#")
    return s

def decode_entities(tokens, labels):
    entities = defaultdict(list)
    cur_lbl, cur_tokens = None, []
    for tok, lab in zip(tokens, labels):
        if lab.startswith("B-"):
            if cur_lbl and cur_tokens:
                entities[cur_lbl].append(_detok(cur_tokens))
            cur_lbl = lab[2:]
            cur_tokens = [tok]
        elif lab.startswith("I-") and cur_lbl == lab[2:]:
            cur_tokens.append(tok)
        else:
            if cur_lbl and cur_tokens:
                entities[cur_lbl].append(_detok(cur_tokens))
            cur_lbl, cur_tokens = None, []
    if cur_lbl and cur_tokens:
        entities[cur_lbl].append(_detok(cur_tokens))
    return entities

emails = [
    "Thanks,\nJohn Doe\nSenior Engineer\nAcme Corp\njohn.doe@acme.com\n+1 555 111 2222",
    "Regards,\nJane Smith, MBA\nDirector, Marketing\nGlobex Inc\njsmith@globex.co.uk\n+44 20 7946 0958"
]

for i, text in enumerate(emails):
    enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
    with torch.no_grad():
        logits = model(**enc).logits
    pred_ids = logits.argmax(-1)[0].tolist()
    toks = tokenizer.convert_ids_to_tokens(enc["input_ids"][0])
    labels = [id2label[i] for i in pred_ids]
    ents = decode_entities(toks, labels)
    print(f"\nEmail {i+1} Entities:\n", json.dumps({k:list(set(v)) for k,v in ents.items()}, indent=2))
