"""
Signature NER — DistilBERT (local) end‑to‑end pipeline
======================================================

This single Python module provides:
 1) Weak‑label generation (silver labels) from raw email bodies with regex + signature heuristics
 2) Token‑classification fine‑tuning using a **locally** available `distilbert-base-uncased` directory
 3) Evaluation with accuracy and a confusion matrix export + entity-wise precision/recall/F1
 4) Inference over large JSON/JSONL and export of results + undetected cases

Expected input format
---------------------
- JSON or JSONL with objects that contain at least: {"id": <str>, "body": <str>}
- Example path used below: `/path/to/records.json`

Model location
--------------
- Set `LOCAL_MODEL_DIR` to the local directory where `distilbert-base-uncased` is already downloaded.

Usage
-----
Train (silver-label from raw, split, fine‑tune, evaluate, save model):

    python signature_ner.py \
        --mode train \
        --input /path/to/records.json \
        --local_model_dir /models/distilbert-base-uncased \
        --output_dir ./signature-ner-distilbert \
        --epochs 3 --batch_size 16

Run inference on larger data and write JSON results:

    python signature_ner.py \
        --mode infer \
        --input /path/to/large_records.jsonl \
        --model_dir ./signature-ner-distilbert \
        --predictions_json ./predictions.json \
        --undetected_json ./undetected.json
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys
from dataclasses import dataclass
from typing import Dict, List, Tuple, Iterable, Optional
from collections import defaultdict

import numpy as np
from sklearn.metrics import confusion_matrix, precision_recall_fscore_support

import torch
from torch.utils.data import Dataset

from transformers import (
    AutoConfig,
    AutoTokenizer,
    AutoModelForTokenClassification,
    DataCollatorForTokenClassification,
    Trainer,
    TrainingArguments,
)

# -----------------------------
# Label scheme (BIO)
# -----------------------------
LABELS = [
    "O",
    "B-NAME", "I-NAME",
    "B-TITLE", "I-TITLE",
    "B-ADDRESS", "I-ADDRESS",
    "B-PHONE", "I-PHONE",
    "B-EMAIL", "I-EMAIL",
]
LABEL2ID = {l: i for i, l in enumerate(LABELS)}
ID2LABEL = {i: l for l, i in LABEL2ID.items()}

SIG_CUES = [
    r"^thanks[,!]*$", r"^thank you[,!]*$", r"^regards[,!]*$", r"^best[,!]*$",
    r"^cheers[,!]*$", r"^sincerely[,!]*$", r"^kind regards[,!]*$",
]

TITLE_LEXICON = set([
    # Common corporate/job titles (expand as needed)
    "ceo", "cto", "coo", "cfo", "vp", "svp", "evp", "avp",
    "president", "director", "managing", "principal", "partner",
    "lead", "manager", "consultant", "analyst", "engineer",
    "developer", "architect", "specialist", "associate",
    "intern", "student", "professor", "dr", "md", "phd",
    "chair", "owner", "founder", "co-founder", "cofounder",
    "sales", "marketing", "operations", "product", "design",
])

EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
PHONE_RE = re.compile(r"(?:\+\d{1,3}[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?)?\d{3}[-.\s]?\d{4}")
# Naïve address cues
ADDRESS_CUES = re.compile(r"\b(?:suite|ste\.?|floor|fl\.|road|rd\.|street|st\.|avenue|ave\.|blvd\.|drive|dr\.|lane|ln\.|p\.o\.|po box|box|\d{5}(?:-\d{4})?|\b(?:usa|united states|canada|uk|india|germany|france|australia)\b)\b",
                          re.IGNORECASE)
NAME_TOKEN = re.compile(r"^(?:[A-Z][a-z]+|[A-Z]\.)$")

# -----------------------------
# Utilities
# -----------------------------
def seed_everything(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def read_records(path: str) -> List[Dict[str, str]]:
    """Load records from .json or .jsonl with fields id, body."""
    items: List[Dict[str, str]] = []
    if path.lower().endswith(".jsonl"):
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                obj = json.loads(line)
                items.append({"id": str(obj.get("id")), "body": obj.get("body", "")})
    else:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                for obj in data:
                    items.append({"id": str(obj.get("id")), "body": obj.get("body", "")})
            elif isinstance(data, dict):
                for obj in data.get("records", []):
                    items.append({"id": str(obj.get("id")), "body": obj.get("body", "")})
            else:
                raise ValueError("Unsupported JSON structure for records")
    return items

# -----------------------------
# Signature block detection (bottom‑up)
# -----------------------------
def detect_signature_lines(body: str, max_lines: int = 18) -> List[str]:
    """Return bottom signature candidate lines (trimmed)."""
    lines = [re.sub(r"\s+", " ", ln.strip()) for ln in body.splitlines()]
    cue_idx = None
    for i in range(len(lines) - 1, -1, -1):
        ln = lines[i].lower()
        if any(re.match(p, ln) for p in SIG_CUES):
            cue_idx = i
            break
    start = cue_idx + 1 if cue_idx is not None else max(0, len(lines) - max_lines)
    cand = [ln for ln in lines[start:] if ln]
    return cand[-max_lines:]

# -----------------------------
# Heuristic silver labeling
# -----------------------------
@dataclass
class Span:
    start: int
    end: int
    label: str

def heuristic_spans(signature_lines: List[str]) -> List[Span]:
    """Return character spans (within the joined signature string)."""
    text = "\n".join(signature_lines)
    spans: List[Span] = []

    def add_spans_from_regex(regex: re.Pattern, lbl: str):
        for m in regex.finditer(text):
            spans.append(Span(m.start(), m.end(), lbl))

    add_spans_from_regex(EMAIL_RE, "EMAIL")
    add_spans_from_regex(PHONE_RE, "PHONE")

    # Address lines
    for m in ADDRESS_CUES.finditer(text):
        line_start = text.rfind("\n", 0, m.start()) + 1
        line_end = text.find("\n", m.end())
        if line_end == -1:
            line_end = len(text)
        spans.append(Span(line_start, line_end, "ADDRESS"))

    # Title lines: look for any token from lexicon
    for match in re.finditer(r"[^\n]+", text):
        ln = match.group(0)
        toks = re.findall(r"[A-Za-z][A-Za-z\-\.]+", ln)
        if any(tok.lower() in TITLE_LEXICON for tok in toks):
            spans.append(Span(match.start(), match.end(), "TITLE"))

    # Name guess: first non-empty line with name-like tokens
    lines = list(re.finditer(r"[^\n]+", text))
    if lines:
        first = lines[0]
        toks = first.group(0).split()
        if 1 <= len(toks) <= 5 and sum(bool(NAME_TOKEN.match(t)) for t in toks) >= max(1, len(toks) - 1):
            spans.append(Span(first.start(), first.end(), "NAME"))
        else:
            anchors = sorted([s.start for s in spans])
            for a in anchors:
                prev_break = text.rfind("\n", 0, a - 1)
                prev_prev_break = text.rfind("\n", 0, prev_break - 1)
                if prev_prev_break == -1:
                    prev_prev_break = 0
                cand_start = prev_prev_break + (0 if prev_prev_break == 0 else 1)
                cand_end = prev_break if prev_break != -1 else a
                if cand_end - cand_start > 0:
                    cand = text[cand_start:cand_end].strip()
                    toks = cand.split()
                    if 1 <= len(toks) <= 5 and sum(bool(NAME_TOKEN.match(t)) for t in toks) >= max(1, len(toks) - 1):
                        spans.append(Span(cand_start, cand_end, "NAME"))
                        break

    # Deduplicate overlaps by heuristic priority
    priority = {"EMAIL": 0, "PHONE": 1, "NAME": 2, "TITLE": 3, "ADDRESS": 4}
    spans.sort(key=lambda s: (s.start, s.end))
    pruned: List[Span] = []
    for sp in sorted(spans, key=lambda s: (priority.get(s.label, 9), -(s.end - s.start))):
        if all(not (sp.start < p.end and p.start < sp.end) for p in pruned):
            pruned.append(sp)
    pruned.sort(key=lambda s: s.start)
    return pruned

# -----------------------------
# Token alignment and BIO conversion
# -----------------------------
def bio_labels_for_text(text: str, tokenizer, spans: List[Span]) -> Tuple[List[int], List[int]]:
    enc = tokenizer(
        text,
        truncation=True,
        max_length=512,
        return_offsets_mapping=True,
        return_tensors=None,
    )
    offsets = enc["offset_mapping"]
    label_ids = [LABEL2ID["O"]] * len(offsets)
    for sp in spans:
        for i, (a, b) in enumerate(offsets):
            if b <= sp.start or a >= sp.end:
                continue
            tag = f"B-{sp.label}" if label_ids[i] == LABEL2ID["O"] else f"I-{sp.label}"
            label_ids[i] = LABEL2ID.get(tag, LABEL2ID["O"])
    input_ids = enc["input_ids"]
    return input_ids, label_ids

class NERDataset(Dataset):
    def __init__(self, examples: List[Dict[str, str]], tokenizer):
        self.examples = examples
        self.tokenizer = tokenizer
        self.features = []
        for ex in examples:
            sig_lines = detect_signature_lines(ex["body"])
            sig_text = "\n".join(sig_lines)
            spans = heuristic_spans(sig_lines)
            input_ids, labels = bio_labels_for_text(sig_text, tokenizer, spans)
            self.features.append({
                "id": ex["id"],
                "text": sig_text,
                "input_ids": input_ids,
                "labels": labels,
                "attention_mask": [1] * len(input_ids),
            })

    def __len__(self):
        return len(self.features)

    def __getitem__(self, idx):
        f = self.features[idx]
        return {
            "input_ids": torch.tensor(f["input_ids"], dtype=torch.long),
            "labels": torch.tensor(f["labels"], dtype=torch.long),
            "attention_mask": torch.tensor(f["attention_mask"], dtype=torch.long),
        }

# -----------------------------
# Metrics
# -----------------------------
def compute_metrics_fn(eval_pred):
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=-1)
    mask = labels != -100 if -100 in labels else np.ones_like(labels, dtype=bool)
    correct = (preds[mask] == labels[mask]).sum()
    total = mask.sum()
    acc = float(correct) / float(total) if total else 0.0
    return {"accuracy": acc}

def save_confusion_and_entity_metrics(all_preds, all_labels, labels_list, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    # Confusion matrix
    cm = confusion_matrix(all_labels, all_preds, labels=list(range(len(labels_list))))
    import csv
    cm_csv = os.path.join(out_dir, "confusion_matrix.csv")
    with open(cm_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["label"] + labels_list)
        for i, row in enumerate(cm):
            writer.writerow([labels_list[i]] + list(row))
    print("Confusion matrix saved to:", cm_csv)

    # Entity-wise precision/recall/F1 (token-level)
    pr, rc, f1, _ = precision_recall_fscore_support(
        all_labels, all_preds, labels=list(range(len(labels_list))), zero_division=0
    )
    entity_metrics = {}
    for i, lbl in enumerate(labels_list):
        entity_metrics[lbl] = {
            "precision": round(float(pr[i]), 4),
            "recall": round(float(rc[i]), 4),
            "f1": round(float(f1[i]), 4),
        }
    metrics_path = os.path.join(out_dir, "entity_metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(entity_metrics, f, indent=2)
    print("Entity-wise metrics saved to:", metrics_path)

# -----------------------------
# Inference: decode BIO to spans and entity strings
# -----------------------------
def decode_entities(tokens: List[str], labels: List[str]) -> Dict[str, List[str]]:
    entities: Dict[str, List[str]] = defaultdict(list)
    cur_lbl = None
    cur_tokens: List[str] = []
    for tok, lab in zip(tokens, labels):
        if lab.startswith("B-"):
            if cur_lbl and cur_tokens:
                entities[cur_lbl].append(_detok(cur_tokens))
            cur_lbl = lab[2:]
            cur_tokens = [tok]
        elif lab.startswith("I-") and cur_lbl == lab[2:]:
            cur_tokens.append(tok)
        else:
            if cur_lbl and cur_tokens:
                entities[cur_lbl].append(_detok(cur_tokens))
            cur_lbl, cur_tokens = None, []
    if cur_lbl and cur_tokens:
        entities[cur_lbl].append(_detok(cur_tokens))
    return entities

def _detok(toks: List[str]) -> str:
    s = " ".join(toks)
    s = s.replace(" ##", "")
    s = s.replace("# #", "#")
    s = re.sub(r"\s+([.,;:!?])", r"\1", s)
    return s.strip()

# -----------------------------
# Train / Evaluate / Save
# -----------------------------
def train(args):
    seed_everything(42)

    tokenizer = AutoTokenizer.from_pretrained(args.local_model_dir)
    config = AutoConfig.from_pretrained(args.local_model_dir, num_labels=len(LABELS), id2label=ID2LABEL, label2id=LABEL2ID)
    model = AutoModelForTokenClassification.from_pretrained(args.local_model_dir, config=config)

    records = read_records(args.input)
    records = [r for r in records if r.get("body", "").strip()]
    random.shuffle(records)

    split = int(0.9 * len(records)) if len(records) > 10 else max(1, len(records) - 1)
    train_records = records[:split]
    val_records = records[split:]

    train_ds = NERDataset(train_records, tokenizer)
    val_ds = NERDataset(val_records, tokenizer)

    data_collator = DataCollatorForTokenClassification(tokenizer)

    training_args = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size,
        learning_rate=args.lr,
        evaluation_strategy="epoch",
        save_strategy="epoch",
        metric_for_best_model="accuracy",
        load_best_model_at_end=True,
        logging_steps=50,
        report_to=[],
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_ds,
        eval_dataset=val_ds,
        tokenizer=tokenizer,
        data_collator=data_collator,
        compute_metrics=compute_metrics_fn,
    )

    trainer.train()

    # Evaluate
    eval_out = trainer.evaluate()
    print("\n== Eval Metrics ==")
    for k, v in eval_out.items():
        print(f"{k}: {v}")

    # Collect predictions for confusion/entity metrics
    all_preds: List[int] = []
    all_labels: List[int] = []
    loader = torch.utils.data.DataLoader(val_ds, batch_size=args.batch_size)
    model.eval()
    for batch in loader:
        with torch.no_grad():
            outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"])
            preds = outputs.logits.argmax(-1).cpu().numpy()
            labels = batch["labels"].cpu().numpy()
            mask = batch["attention_mask"].cpu().numpy().astype(bool)
            for p, l, m in zip(preds, labels, mask):
                all_preds.extend(np.array(p)[m].tolist())
                all_labels.extend(np.array(l)[m].tolist())

    os.makedirs(args.output_dir, exist_ok=True)
    save_confusion_and_entity_metrics(all_preds, all_labels, LABELS, args.output_dir)

    # Save model
    trainer.save_model(args.output_dir)
    tokenizer.save_pretrained(args.output_dir)
    print("Model saved to:", args.output_dir)

    # Export undetected cases from validation where model predicted no entities
    undetected = []
    for rec in val_records:
        sig_lines = detect_signature_lines(rec["body"])
        text = "\n".join(sig_lines)
        if not text.strip():
            undetected.append({"id": rec["id"], "body": rec["body"]})
            continue
        enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        with torch.no_grad():
            out = model(**enc)
        pred_ids = out.logits.argmax(-1)[0].tolist()
        toks = tokenizer.convert_ids_to_tokens(enc["input_ids"][0])
        labs = [ID2LABEL[i] for i in pred_ids]
        ents = decode_entities(toks, labs)
        if not any(ents.values()):
            undetected.append({"id": rec["id"], "body": rec["body"]})

    undetected_path = os.path.join(args.output_dir, "undetected_val.json")
    with open(undetected_path, "w", encoding="utf-8") as f:
        json.dump(undetected, f, ensure_ascii=False, indent=2)
    print("Undetected validation cases:", len(undetected), "=>", undetected_path)

# -----------------------------
# Inference
# -----------------------------
def infer(args):
    tokenizer = AutoTokenizer.from_pretrained(args.model_dir)
    config = AutoConfig.from_pretrained(args.model_dir)
    model = AutoModelForTokenClassification.from_pretrained(args.model_dir, config=config)

    records = read_records(args.input)
    preds_out = []
    undetected = []

    for rec in records:
        sig_lines = detect_signature_lines(rec["body"])
        text = "\n".join(sig_lines)
        if not text.strip():
            undetected.append({"id": rec["id"], "body": rec["body"]})
            preds_out.append({"id": rec["id"], "entities": {}, "raw_signature": ""})
            continue

        enc = tokenizer(text, return_tensors="pt", truncation=True, max_length=512)
        with torch.no_grad():
            out = model(**enc)
        pred_ids = out.logits.argmax(-1)[0].tolist()
        toks = tokenizer.convert_ids_to_tokens(enc["input_ids"][0])
        labs = [ID2LABEL[i] for i in pred_ids]
        ents = decode_entities(toks, labs)

        if not any(ents.values()):
            undetected.append({"id": rec["id"], "body": rec["body"]})

        preds_out.append({
            "id": rec["id"],
            "entities": {k: sorted(list(set(v))) for k, v in ents.items()},
            "raw_signature": text,
        })

    if args.predictions_json:
        with open(args.predictions_json, "w", encoding="utf-8") as f:
            json.dump(preds_out, f, ensure_ascii=False, indent=2)
        print("Predictions saved to:", args.predictions_json)

    if args.undetected_json:
        with open(args.undetected_json, "w", encoding="utf-8") as f:
            json.dump(undetected, f, ensure_ascii=False, indent=2)
        print("Undetected saved to:", args.undetected_json)

# -----------------------------
# CLI
# -----------------------------
def parse_args(argv: Optional[List[str]] = None):
    p = argparse.ArgumentParser("Signature NER training & inference (local DistilBERT)")
    p.add_argument("--mode", choices=["train", "infer"], required=True)
    p.add_argument("--input", required=True, help="Path to records .json/.jsonl")

    # train options
    p.add_argument("--local_model_dir", default="./distilbert-base-uncased", help="Local dir for base model")
    p.add_argument("--output_dir", default="./signature-ner-distilbert")
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--lr", type=float, default=5e-5)

    # inference options
    p.add_argument("--model_dir", default="./signature-ner-distilbert")
    p.add_argument("--predictions_json", default="./predictions.json")
    p.add_argument("--undetected_json", default="./undetected.json")

    return p.parse_args(argv)

if __name__ == "__main__":
    args = parse_args()
    if args.mode == "train":
        train(args)
    else:
        infer(args)
